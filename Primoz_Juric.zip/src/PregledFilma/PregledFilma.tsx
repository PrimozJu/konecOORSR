


import { useState } from 'react'
import { Button , Form } from 'react-bootstrap';
import { Ioddaja } from '../TVoddaje/TvOddaje';
interface Props {

   
    item: Ioddaja;
}
const PregledFIlma = (props: Props) =>{


    return(
        <details>
  <summary>{props.item.ime}</summary>
  <div> {props.item.status == true ?  "OGLEDANO" : "neogledano :-("} </div>
    <p> {props.item.opis} </p>
</details>
    
       
        
        );
}
 export  default PregledFIlma;