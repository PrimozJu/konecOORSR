import { useState } from 'react'
import { Ioddaja, oddaje } from './TVoddaje/TvOddaje'
//import './App.css'
import PregledFilma from './PregledFilma/PregledFilma';
import Dodaj from './Dodaj.tsx/Dodaj';
function App() {
  const [seznam, setSeznam] = useState<Ioddaja[]>(oddaje);



  return (
    <div className="App">
        <ul>
        {seznam.map((item, index) => (
          <li key={index}> <PregledFilma item={item}/></li>

        ))}
      </ul>
    <Dodaj seznam={seznam} setSeznam={setSeznam}/>
    </div>
  )
}

export default App
