
export interface Ioddaja {
    ime: string;
    status: boolean;
    opis?: string
}

const oddaja1: Ioddaja = {ime: "oddaja1", status: true};

const oddaja2: Ioddaja = {ime: "oddaja2", status: false};
//[oddaja1, oddaja2] 

export const oddaje: Ioddaja[] = [oddaja1, oddaja2];