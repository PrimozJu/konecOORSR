
import { useState } from 'react'
import { Button , Form } from 'react-bootstrap';
import { Ioddaja } from '../TVoddaje/TvOddaje';
interface Props {

    seznam: Ioddaja[];
    setSeznam: React.Dispatch<React.SetStateAction<Ioddaja[]>>;
}

const Dodaj = (props: Props) => {
   
   
    const [ime, setIme] = useState<string>("");
    const  [status, setStatus]  = useState<boolean>(false);
    const [opis, setOpis] = useState<string>("");

    

    const handleFormSubmit = (event: { preventDefault: () => void; }) => {
        event.preventDefault();
        console.log("handle");
        

        const newOddaja = { ime: ime, status: status , opis: opis };

        props.setSeznam([...props.seznam, newOddaja]);//doda not in se vse updejta




    };



    return(
        <div className="row border border-warning rounded ">
            <div className="col">
                <h2>Dodaj Film</h2>
                <Form onSubmit={handleFormSubmit}>
                    <div className="row mb-3">
                        <div className="col-md-2">
                            <Form.Label>Ime</Form.Label>
                        </div>
                        <div className="col-md-10">
                            <Form.Control type="text" placeholder="Vnesi ime" value={ime} onChange={(event) => setIme(event.target.value)} />
                        </div>
                    </div>
                    <div className="row mb-3">
                        <div className="col-md-2">
                            <Form.Label>Ogledan?</Form.Label>
                        </div>
                        <div className="col-md-10">
                            <Form.Check
                                type="checkbox"
                                checked={status}
                                onChange={(event) => setStatus(event.target.checked)}
                                className="btn-xl " 
                            />

                        </div>

                    </div>

                    <div className="row mb-3">
                        <div className="col-md-2">
                            <Form.Label>Opis</Form.Label>
                        </div>
                        <div className="col-md-10">
                            <Form.Control type="text" placeholder="Vnesi Opis" value={opis} onChange={(event) => setOpis(event.target.value)} />
                        </div>
                    </div>
                    
            

                    <Button variant="primary" type="submit">
                        Dodaj Film
                    </Button>
                    
                </Form>
            </div>
        </div>
    )

}
export default Dodaj;